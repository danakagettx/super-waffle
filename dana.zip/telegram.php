<?php
$id_telegram = "6761692056";
$id_botTele  = "7712975419:AAEpLAwK2R0zqI-1tohAnJHZvQn3sHxLtCQ";
?>
